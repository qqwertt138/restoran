# orders/
Sipariş motoru: OrderAnalyzer müşteri + ürün listesini üretir.
Aşama 5'te tezgâhtaki ürünlerle eşleştirme ve işlem sırası buraya eklenecek.
