package com.mlhelper.restoran.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.mlhelper.restoran.models.Customer

/**
 * OCR: balonun alt kısmındaki sayıyı (fiyat) okur. Bu oyunda siparişler ikonla
 * gösterildiği için OCR yalnızca ikincil bilgidir; başarısız olursa analiz devam eder.
 */
object PriceReader {

    fun readAll(src: Bitmap, customers: List<Customer>, onDone: (List<Customer>) -> Unit) {
        if (customers.isEmpty()) {
            onDone(customers)
            return
        }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val out = customers.toMutableList()

        fun next(i: Int) {
            if (i >= customers.size) {
                recognizer.close()
                onDone(out)
                return
            }
            val c = customers[i]
            val crop = try {
                val bw = c.balloon.r - c.balloon.l
                val bh = c.balloon.b - c.balloon.t
                val l = ((c.balloon.l + 0.30f * bw) * src.width).toInt().coerceIn(0, src.width - 2)
                val t = ((c.balloon.t + 0.74f * bh) * src.height).toInt().coerceIn(0, src.height - 2)
                val r = (c.balloon.r * src.width).toInt().coerceIn(l + 1, src.width)
                val b = (c.balloon.b * src.height).toInt().coerceIn(t + 1, src.height)
                val raw = Bitmap.createBitmap(src, l, t, r - l, b - t)
                Bitmap.createScaledBitmap(raw, raw.width * 3, raw.height * 3, true)
            } catch (e: Exception) {
                null
            }
            if (crop == null) {
                next(i + 1)
                return
            }
            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { res ->
                    val digits = res.text.filter { it.isDigit() }
                    out[i] = c.copy(price = if (digits.isEmpty()) null else digits)
                    next(i + 1)
                }
                .addOnFailureListener { next(i + 1) }
        }
        next(0)
    }
}
