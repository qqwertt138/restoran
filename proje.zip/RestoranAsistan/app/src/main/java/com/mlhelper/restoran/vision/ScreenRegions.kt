package com.mlhelper.restoran.vision

import com.mlhelper.restoran.models.RectF01

/** Videodan ölçülen bölge oranları. Hepsi ekran genişliği/yüksekliğine göredir. */
object ScreenRegions {
    /** Müşteriler ve sipariş balonlarının bulunduğu üst bölge. */
    val CUSTOMER_ZONE = RectF01(0.25f, 0.08f, 0.82f, 0.50f)

    /** Balonun ekran yüksekliğine oranla yaklaşık yüksekliği. */
    const val BALLOON_HEIGHT = 0.27f

    /** Müşterinin balonun soluna doğru yaklaşık genişliği. */
    const val CUSTOMER_WIDTH = 0.11f
}
