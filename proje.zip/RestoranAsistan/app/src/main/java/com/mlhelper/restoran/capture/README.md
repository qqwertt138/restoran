# capture/
Ekran görüntüsü alma. Şu an: galeriden seçilen görüntüyü yükler (ScreenshotLoader).
Sonraki adım: MediaProjection ile canlı ekran yakalama.
