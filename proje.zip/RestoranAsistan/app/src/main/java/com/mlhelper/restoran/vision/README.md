# vision/
Görüntü işleme: ekran bölgeleri (ScreenRegions), balon bulma (BalloonDetector),
balon içi ikon ayırma (ItemSegmenter), ikon tanıma (ItemClassifier + ItemReferences).
Tüm koordinatlar 0..1 oranlıdır; piksel sabitlenmez.
