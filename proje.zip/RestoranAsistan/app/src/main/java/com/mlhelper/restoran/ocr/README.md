# ocr/
ML Kit ile yazı/sayı okuma (PriceReader). OCR ikincildir; asıl tanıma ikon görüntüsüyle yapılır.
