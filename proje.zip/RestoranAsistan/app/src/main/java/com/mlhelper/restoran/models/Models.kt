package com.mlhelper.restoran.models

/** Ekranın 0..1 arasına oranlanmış dikdörtgeni (piksel değil, böylece çözünürlükten bağımsız). */
data class RectF01(val l: Float, val t: Float, val r: Float, val b: Float)

/** Sipariş balonundaki tek bir ürün. known=false ise ikon tanınamadı. */
data class OrderItem(
    val label: String,
    val confidence: Float,
    val box: RectF01,
    val known: Boolean
)

data class Customer(
    val index: Int,
    val box: RectF01,
    val balloon: RectF01,
    val items: List<OrderItem>,
    val price: String?
)

data class AnalysisResult(
    val customers: List<Customer>,
    val notes: List<String>
)
