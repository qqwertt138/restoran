# models/
Veri yapıları: RectF01 (oranlı kutu), OrderItem, Customer, AnalysisResult.
