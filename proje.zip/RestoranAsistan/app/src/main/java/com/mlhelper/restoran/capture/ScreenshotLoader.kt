package com.mlhelper.restoran.capture

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

/**
 * AŞAMA 1: Galeriden seçilen ekran görüntüsünü yükler.
 * (Canlı ekran yakalama / MediaProjection sonraki aşamada buraya eklenecek.)
 */
object ScreenshotLoader {
    fun load(resolver: ContentResolver, uri: Uri, maxWidth: Int = 2000): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxWidth) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
}
