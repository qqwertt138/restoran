package com.mlhelper.restoran.vision

import android.graphics.Bitmap
import com.mlhelper.restoran.models.RectF01

/** Müşteri bölgesinde krem renkli, dikey sipariş balonlarını bulur. */
object BalloonDetector {
    const val WORK_WIDTH = 410

    fun toWorkBitmap(src: Bitmap): Bitmap {
        val h = (src.height * WORK_WIDTH.toFloat() / src.width).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, WORK_WIDTH, h, true)
    }

    fun isCream(p: Int): Boolean {
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        return r > 225 && g > 205 && b > 150 && r >= g && g >= b && (r - b) in 18..90
    }

    fun detect(px: IntArray, w: Int, h: Int): List<RectF01> {
        val zone = ScreenRegions.CUSTOMER_ZONE
        val y0 = (h * zone.t).toInt()
        val y1 = (h * zone.b).toInt()
        val x0 = (w * zone.l).toInt()
        val x1 = (w * zone.r).toInt()

        val mask = BooleanArray(w * h)
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                mask[y * w + x] = isCream(px[y * w + x])
            }
        }

        val seen = BooleanArray(w * h)
        val queue = IntArray(w * h)
        val result = ArrayList<RectF01>()

        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val start = y * w + x
                if (!mask[start] || seen[start]) continue

                var head = 0
                var tail = 0
                queue[tail++] = start
                seen[start] = true
                var l = x
                var r = x
                var t = y
                var b = y
                var n = 0

                while (head < tail) {
                    val cur = queue[head++]
                    val cx = cur % w
                    val cy = cur / w
                    n++
                    if (cx < l) l = cx
                    if (cx > r) r = cx
                    if (cy < t) t = cy
                    if (cy > b) b = cy

                    for (d in 0 until 4) {
                        val nx = cx + (if (d == 0) 1 else if (d == 1) -1 else 0)
                        val ny = cy + (if (d == 2) 1 else if (d == 3) -1 else 0)
                        if (nx < x0 || nx >= x1 || ny < y0 || ny >= y1) continue
                        val ni = ny * w + nx
                        if (mask[ni] && !seen[ni]) {
                            seen[ni] = true
                            queue[tail++] = ni
                        }
                    }
                }

                val bw = r - l + 1
                val bh = b - t + 1
                val ratio = bh.toFloat() / bw
                val fill = n.toFloat() / (bw * bh)
                if (bh >= h * 0.12f && bw >= w * 0.03f && ratio in 1.4f..4.5f && fill > 0.35f) {
                    result.add(
                        RectF01(
                            l.toFloat() / w, t.toFloat() / h,
                            (r + 1).toFloat() / w, (b + 1).toFloat() / h
                        )
                    )
                }
            }
        }
        return result.sortedBy { it.l }
    }
}
