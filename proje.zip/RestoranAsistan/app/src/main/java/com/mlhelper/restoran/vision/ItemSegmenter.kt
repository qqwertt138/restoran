package com.mlhelper.restoran.vision

import com.mlhelper.restoran.models.RectF01

data class PxRect(val l: Int, val t: Int, val r: Int, val b: Int)

/** Bir balonun içindeki ürün ikonlarını (1 veya 2 adet üst üste) ayırır. */
object ItemSegmenter {

    fun segment(px: IntArray, w: Int, h: Int, balloon: RectF01): List<PxRect> {
        val left = Math.round(balloon.l * w)
        val right = Math.round(balloon.r * w) - 1
        val top = Math.round(balloon.t * h)
        val bottom = Math.round(balloon.b * h) - 1
        val bw = right - left + 1
        val bh = bottom - top + 1
        if (bw < 4 || bh < 8) return emptyList()

        val x0 = (left + (0.30f * bw).toInt()).coerceIn(0, w - 2)
        val x1 = (right - (0.05f * bw).toInt()).coerceIn(x0 + 1, w)
        val y0 = (top + (0.03f * bh).toInt()).coerceIn(0, h - 2)
        val y1 = (top + (0.72f * bh).toInt()).coerceIn(y0 + 1, h)

        val ink = BooleanArray(y1 - y0)
        for (y in y0 until y1) {
            var count = 0
            for (x in x0 until x1) {
                if (!BalloonDetector.isCream(px[y * w + x])) count++
            }
            ink[y - y0] = count >= 0.12f * (x1 - x0)
        }

        val segs = ArrayList<IntArray>()
        var start = -1
        for (i in 0..ink.size) {
            val v = i < ink.size && ink[i]
            if (v && start < 0) start = i
            if (!v && start >= 0) {
                segs.add(intArrayOf(start, i - 1))
                start = -1
            }
        }

        val merged = ArrayList<IntArray>()
        for (s in segs) {
            if (merged.isNotEmpty() && s[0] - merged.last()[1] <= 0.03f * bh) {
                merged.last()[1] = s[1]
            } else {
                merged.add(s)
            }
        }

        val minHeight = 0.09f * bh
        return merged
            .filter { (it[1] - it[0] + 1) >= minHeight }
            .map { PxRect(x0, y0 + it[0], x1, y0 + it[1] + 1) }
    }
}
