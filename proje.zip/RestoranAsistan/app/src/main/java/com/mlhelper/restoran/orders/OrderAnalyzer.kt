package com.mlhelper.restoran.orders

import android.graphics.Bitmap
import com.mlhelper.restoran.models.AnalysisResult
import com.mlhelper.restoran.models.Customer
import com.mlhelper.restoran.models.OrderItem
import com.mlhelper.restoran.models.RectF01
import com.mlhelper.restoran.vision.BalloonDetector
import com.mlhelper.restoran.vision.ItemClassifier
import com.mlhelper.restoran.vision.ItemSegmenter
import com.mlhelper.restoran.vision.ScreenRegions

/** AŞAMA 2-3: Ekran görüntüsünden müşterileri ve sipariş balonlarındaki ürünleri çıkarır. */
object OrderAnalyzer {

    fun analyze(src: Bitmap): AnalysisResult {
        val notes = ArrayList<String>()
        if (src.height > src.width) {
            notes.add("Görüntü dikey. Oyun yatay çalışır; yatay ekran görüntüsü seçin.")
        }

        val small = BalloonDetector.toWorkBitmap(src)
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        val balloons = BalloonDetector.detect(px, w, h)
        if (balloons.isEmpty()) {
            notes.add("Hiç sipariş balonu bulunamadı (müşteri yok ya da ekran farklı).")
        }

        val customers = ArrayList<Customer>()
        for ((i, raw) in balloons.withIndex()) {
            // Aciliyet kenarlığı yüzünden balon kısmi bulunduysa standart boya tamamla
            val bal = if (raw.b - raw.t < ScreenRegions.BALLOON_HEIGHT * 0.9f) {
                raw.copy(t = (raw.b - ScreenRegions.BALLOON_HEIGHT).coerceAtLeast(0f))
            } else raw

            val items = ArrayList<OrderItem>()
            for (seg in ItemSegmenter.segment(px, w, h, bal)) {
                val sig = ItemClassifier.signature(px, w, seg)
                val m = ItemClassifier.classify(sig)
                items.add(
                    OrderItem(
                        label = if (m.known) m.label else "Belirsiz",
                        confidence = m.confidence,
                        box = RectF01(
                            seg.l.toFloat() / w, seg.t.toFloat() / h,
                            seg.r.toFloat() / w, seg.b.toFloat() / h
                        ),
                        known = m.known
                    )
                )
            }

            val customerBox = RectF01(
                (bal.l - ScreenRegions.CUSTOMER_WIDTH).coerceAtLeast(0f),
                bal.t + 0.05f,
                bal.l,
                0.46f
            )
            customers.add(Customer(i + 1, customerBox, bal, items, null))
        }

        if (customers.any { c -> c.items.any { !it.known } }) {
            notes.add("Belirsiz ikon var: otomasyon aşamasında güvenlik gereği durdurulacak.")
        }
        return AnalysisResult(customers, notes)
    }
}
