# accessibility/
Aşama 8: Android Accessibility Service (dokunma/gesture gönderme). Şu an boş; test modu bitmeden eklenmeyecek.
