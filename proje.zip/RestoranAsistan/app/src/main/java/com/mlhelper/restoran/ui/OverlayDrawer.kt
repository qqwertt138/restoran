package com.mlhelper.restoran.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.mlhelper.restoran.models.AnalysisResult
import com.mlhelper.restoran.models.RectF01

/** Algılanan müşteri, balon ve ürün kutularını görüntünün üzerine çizer. */
object OverlayDrawer {

    fun draw(src: Bitmap, result: AnalysisResult): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bmp)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()

        fun stroke(color: Int) = Paint().apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = (w / 300f).coerceAtLeast(2f)
        }
        val text = Paint().apply {
            color = Color.WHITE
            textSize = w / 55f
            isFakeBoldText = true
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        val customerPaint = stroke(Color.GREEN)
        val balloonPaint = stroke(Color.YELLOW)
        val knownPaint = stroke(Color.CYAN)
        val unknownPaint = stroke(Color.RED)

        fun rect(r: RectF01, p: Paint) = canvas.drawRect(r.l * w, r.t * h, r.r * w, r.b * h, p)

        for (c in result.customers) {
            rect(c.box, customerPaint)
            canvas.drawText("M${c.index}", c.box.l * w + 4f, c.box.t * h - 6f, text)
            rect(c.balloon, balloonPaint)
            for (item in c.items) {
                rect(item.box, if (item.known) knownPaint else unknownPaint)
                canvas.drawText(item.label, item.box.l * w, item.box.b * h + text.textSize, text)
            }
        }
        return bmp
    }
}
