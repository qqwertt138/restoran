# automation/
Aşama 6-8: dokunma koordinatı hesabı, test modu simülasyonu, güvenlik durdurma, işlem logları,
her dokunuştan önce ekranı yeniden okuma. Şu an boş.
