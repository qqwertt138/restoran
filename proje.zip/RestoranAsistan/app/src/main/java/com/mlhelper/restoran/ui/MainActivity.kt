package com.mlhelper.restoran.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.mlhelper.restoran.capture.ScreenshotLoader
import com.mlhelper.restoran.models.AnalysisResult
import com.mlhelper.restoran.models.Customer
import com.mlhelper.restoran.ocr.PriceReader
import com.mlhelper.restoran.orders.OrderAnalyzer

/** Ana ekran: Aşama 1-3 (ekran görüntüsü yükle, müşteri ve sipariş tespiti, test modu). */
class MainActivity : Activity() {

    private val pickCode = 101
    private var running = false

    private lateinit var tvCount: TextView
    private lateinit var tvOrders: TextView
    private lateinit var tvLast: TextView
    private lateinit var tvErrors: TextView
    private lateinit var tvMode: TextView
    private lateinit var image: ImageView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.parseColor("#222222"))
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        root.addView(label("Restoran Asistan", 22f, true))
        root.addView(label("Aşama 1-3: ekran görüntüsü → müşteri → sipariş tespiti (gerçek dokunma YOK)", 13f))

        root.addView(button("Ekran görüntüsü seç ve analiz et") { pickImage() })

        val modeSwitch = Switch(this).apply {
            text = "Test modu (gerçek oyuna dokunmaz)"
            isChecked = true
            setOnCheckedChangeListener { _, checked ->
                tvMode.text = if (checked) "Mod: TEST (güvenli)" else "Mod: GERÇEK (Aşama 8'de açılacak)"
            }
        }
        root.addView(modeSwitch)
        tvMode = label("Mod: TEST (güvenli)", 13f)
        root.addView(tvMode)

        root.addView(button("Otomasyonu Başlat") {
            Toast.makeText(this, "Otomatik dokunma Aşama 8'de eklenecek. Şimdi yalnızca analiz var.", Toast.LENGTH_LONG).show()
            setLast("Başlat'a basıldı: otomasyon henüz yok")
        })

        val stop = Button(this).apply {
            text = "DURDUR"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#D32F2F"))
            setOnClickListener {
                running = false
                setLast("DURDUR'a basıldı: her şey durduruldu")
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(72)
            ).apply { topMargin = dp(8); bottomMargin = dp(8) }
        }
        root.addView(stop)

        tvCount = label("Algılanan müşteri sayısı: -", 16f, true)
        tvOrders = label("Algılanan siparişler: -")
        tvLast = label("Son yapılan işlem: -")
        tvErrors = label("Hata mesajları: -")
        root.addView(tvCount)
        root.addView(tvOrders)
        root.addView(tvLast)
        root.addView(tvErrors)

        image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(image)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun setLast(text: String) {
        tvLast.text = "Son yapılan işlem: $text"
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "Oyun ekran görüntüsünü seç"), pickCode)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        analyze(uri)
    }

    private fun analyze(uri: Uri) {
        setLast("Ekran görüntüsü analiz ediliyor...")
        tvErrors.text = "Hata mesajları: -"
        Thread {
            try {
                val bmp = ScreenshotLoader.load(contentResolver, uri)
                if (bmp == null) {
                    runOnUiThread { tvErrors.text = "Hata mesajları: Görüntü açılamadı" }
                    return@Thread
                }
                val result = OrderAnalyzer.analyze(bmp)
                runOnUiThread { show(bmp, result) }
                PriceReader.readAll(bmp, result.customers) { withPrices ->
                    runOnUiThread { show(bmp, result.copy(customers = withPrices)) }
                }
            } catch (e: Throwable) {
                runOnUiThread { tvErrors.text = "Hata mesajları: ${e.javaClass.simpleName}: ${e.message}" }
            }
        }.start()
    }

    private fun show(bmp: Bitmap, result: AnalysisResult) {
        tvCount.text = "Algılanan müşteri sayısı: ${result.customers.size}"
        tvOrders.text = if (result.customers.isEmpty()) {
            "Algılanan siparişler: yok"
        } else {
            "Algılanan siparişler:\n" + result.customers.joinToString("\n") { describe(it) }
        }
        setLast("Analiz tamamlandı (test modu, dokunma yok)")
        tvErrors.text = if (result.notes.isEmpty()) "Hata mesajları: yok"
        else "Hata mesajları:\n" + result.notes.joinToString("\n")
        image.setImageBitmap(OverlayDrawer.draw(bmp, result))
    }

    private fun describe(c: Customer): String {
        val items = if (c.items.isEmpty()) "ürün okunamadı"
        else c.items.joinToString(" + ") { if (it.known) it.label else "Belirsiz?" }
        val price = if (c.price != null) "  (sayı: ${c.price})" else ""
        return "Müşteri ${c.index} → $items$price"
    }
}
