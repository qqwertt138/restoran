package com.mlhelper.restoran.vision

/** İkonun renk imzasını çıkarır ve en yakın referansla eşleştirir (OCR'dan bağımsız görsel doğrulama). */
object ItemClassifier {
    private const val GRID = 4
    const val KNOWN_DISTANCE = 0.09f
    private const val MAX_DISTANCE = 0.12f

    class Match(val label: String, val distance: Float) {
        val known: Boolean get() = distance < KNOWN_DISTANCE
        val confidence: Float get() = (1f - distance / MAX_DISTANCE).coerceIn(0f, 1f)
    }

    fun signature(px: IntArray, w: Int, rect: PxRect): FloatArray {
        val out = FloatArray(GRID * GRID * 3)
        var k = 0
        for (gy in 0 until GRID) {
            for (gx in 0 until GRID) {
                val xa = rect.l + (rect.r - rect.l) * gx / GRID
                var xb = rect.l + (rect.r - rect.l) * (gx + 1) / GRID
                val ya = rect.t + (rect.b - rect.t) * gy / GRID
                var yb = rect.t + (rect.b - rect.t) * (gy + 1) / GRID
                if (xb <= xa) xb = xa + 1
                if (yb <= ya) yb = ya + 1
                var rs = 0f
                var gs = 0f
                var bs = 0f
                var n = 0
                for (y in ya until yb) {
                    for (x in xa until xb) {
                        val p = px[y * w + x]
                        rs += ((p shr 16) and 0xFF)
                        gs += ((p shr 8) and 0xFF)
                        bs += (p and 0xFF)
                        n++
                    }
                }
                out[k++] = rs / n / 255f
                out[k++] = gs / n / 255f
                out[k++] = bs / n / 255f
            }
        }
        return out
    }

    fun classify(sig: FloatArray): Match {
        var bestLabel = "?"
        var best = Float.MAX_VALUE
        for (ref in ItemReferences.ALL) {
            var sum = 0f
            for (i in sig.indices) {
                val d = sig[i] - ref.sig[i]
                sum += d * d
            }
            val dist = Math.sqrt((sum / sig.size).toDouble()).toFloat()
            if (dist < best) {
                best = dist
                bestLabel = ref.label
            }
        }
        return Match(bestLabel, best)
    }
}
