# ui/
Ekranlar: MainActivity (ana ekran + test modu) ve OverlayDrawer (kutuları görüntü üzerine çizer).
