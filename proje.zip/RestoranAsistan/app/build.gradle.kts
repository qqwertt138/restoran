plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mlhelper.restoran"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mlhelper.restoran"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-asama3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
